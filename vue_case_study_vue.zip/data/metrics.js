export default [
  { value: '40%', label: 'Faster Task Completion' },
  { value: '85%', label: 'User Satisfaction' },
  { value: '60%', label: 'Reduced Support Tickets' }
]