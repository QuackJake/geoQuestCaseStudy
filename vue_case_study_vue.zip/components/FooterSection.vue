<template>
  <footer class="bg-primary text-primary-foreground py-12 px-6">
    <div class="max-w-6xl mx-auto text-center">
      <h3 class="text-2xl font-semibold mb-4">Let's Create Something Amazing</h3>
      <p class="text-primary-foreground/80 mb-6">
        Interested in working together? I'd love to hear about your next project.
      </p>
      <button class="bg-accent text-accent-foreground px-6 py-3 rounded-lg font-semibold hover:bg-accent/90 transition-colors duration-200">
        Get In Touch
      </button>
    </div>
  </footer>
</template>